package com.care.root.common;

public interface SessionName {
	//로그인 성공 시 세션
	public String LOGIN = "loginUser";
	//= final static String LOGIN = "";
}
