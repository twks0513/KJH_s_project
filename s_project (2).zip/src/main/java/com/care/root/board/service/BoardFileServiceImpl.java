package com.care.root.board.service;

import org.springframework.stereotype.Service;

@Service
public class BoardFileServiceImpl implements BoardFileService{

}
